import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Pat } from "./Pat.model";


@Injectable()
export class PatService{
    constructor(private httpClient:HttpClient){}

    getPats():Observable<Pat[]>{
        return this.httpClient.get<Pat[]>('http://localhost:8088/api/v1/patients');
    }
}
