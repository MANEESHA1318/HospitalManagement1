import { Component, OnInit } from '@angular/core';
import { Pat } from './Pat.model';
import { PatService } from './pats.service';

@Component({
  selector: 'app-pats',
  templateUrl: './pats.component.html',
  styleUrls: ['./pats.component.css']
})

export class PatsComponent implements OnInit {
  pats:Pat[] | undefined;
    constructor(private patService:PatService) { }
  

 ngOnInit(): void {
    this.patService.getPats().subscribe((p)=>{
      this.pats = p;
  });
  }

}

