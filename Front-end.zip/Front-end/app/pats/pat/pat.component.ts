import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pat',
  templateUrl: './pat.component.html',
  styleUrls: ['./pat.component.css']
})
export class PatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
