import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { AuthenticationStatus } from "../models/AuthenticationStatus.model";


@Injectable({
    providedIn: 'root',
})

export class AdminService {
//     constructor(private _http:HttpClient) { }

// public loginAdminFromRemote(adminlogin: AdminLogin):Observable<any> {
//     return this._http.post<any>("http://localhost:8088/api/v1/adminlogin", adminlogin)
//   }
//   handleError(error: Response){
    constructor(private httpClient: HttpClient) {}
    authenticated(
        username: string,
        password: string
    ): Observable<AuthenticationStatus> {
        // console.log(email, password);
        let body = {
            username: username,
            password: password,
        };
        let headers = new HttpHeaders({
            'content-type': 'application/json',
        });
        return this.httpClient.post<AuthenticationStatus>(
            'http://localhost:8088/api/v1/adminlogin',
            body,
            {
                headers: headers,
            }
        );
    }
}
