import { Component, OnInit } from '@angular/core';
import { Appointment } from './Appointment.model';
import { AppointmentService } from './appointments.service';
@Component({
  selector: 'app-appointments',
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.css']
})
export class AppointmentsComponent implements OnInit {
  appointments:Appointment[] | undefined;
  constructor(private appointmentService:AppointmentService) { }

 ngOnInit(): void {
    this.appointmentService.getAppointments().subscribe((appo)=>{
      this.appointments = appo;
  });
  }
  deleteAppointment(ap_id: number){
    alert('are you sure you want to delete??') ;
this.appointmentService.deleteAppointment(ap_id).subscribe((apId)=>{
  this.getAppointment();
})


}
  getAppointment() {
    throw new Error('Method not implemented.');
  }
}
