import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Appointment } from "./Appointment.model";


@Injectable()
export class AppointmentService{
    constructor(private httpClient:HttpClient){}

    getAppointments():Observable<Appointment[]>{
        return this.httpClient.get<Appointment[]>('http://localhost:8088/api/v1/appointments');
    }

    deleteAppointment(ap_id: number):Observable<Appointment[]>{
        console.log(ap_id)
        return this.httpClient.delete<Appointment[]>('http://localhost:8088/api/v1/appointments/'+ ap_id);
    }

}
