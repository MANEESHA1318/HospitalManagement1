import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { AdminComponent } from './admin/admin.component';
import { AboutComponent } from './about/about.component';
import { DoctorComponent } from './doctor/doctor.component';
import { FeedbackComponent} from './feedback/feedback.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
//import { AdminsignupComponent } from './admin/adminsignup/adminsignup.component';
import { DoctorsignupComponent } from './doctor/doctorsignup/doctorsignup.component';
import { PatienthomepageComponent } from './patienthomepage/patienthomepage.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { AdminmainpageComponent } from './admin/adminmainpage/adminmainpage.component';
import { DoctorHomeComponent } from './doctor-home/doctor-home.component';
import { DoctorsComponent } from './doctors/doctors.component';
import { DocProfileComponent } from './doc-profile/doc-profile.component';
import { PatientProfileComponent } from './patient-profile/patient-profile.component';
import { PatientComponent } from './patient/patient.component';
import { PatientsignupComponent } from './patient/patientsignup/patientsignup.component';
import { PatientsComponent } from './patients/patients.component';
import { FeedbacksComponent } from './feedbacks/feedbacks.component';
import { AppointmentsComponent } from './appointments/appointments.component';
import { DischargesComponent } from './discharges/discharges.component';
import { InvoicesComponent } from './invoices/invoices.component';
import { DocsComponent } from './docs/docs.component';
import { PatsComponent } from './pats/pats.component';
import { AppointsComponent } from './appoints/appoints.component';
import { InvoicComponent } from './invoic/invoic.component';


const routes: Routes = [
  {path:"header", component:HeaderComponent},
  {path:"admin", component:AdminComponent},
  {path:"doctor", component:DoctorComponent},
  {path:"doc-profile", component:DocProfileComponent},
  {path:"patient", component:PatientComponent},
  {path:"patient-profile", component:PatientProfileComponent},
  {path:"about", component:AboutComponent},
  {path:"feedback", component:FeedbackComponent},
  {path:"patienthomepage", component:PatienthomepageComponent},
 {path:"appointment",component:AppointmentComponent },
 {path:"invoice", component:InvoiceComponent },
 {path:"adminmainpage", component:AdminmainpageComponent},
  // {path:"contact", component:HeaderComponent},
 // {path:"adminsignup", component:AdminsignupComponent},
  {path:"doctorsignup", component:DoctorsignupComponent},
  {path:"patientsignup", component:PatientsignupComponent},
  {path:"", component:HomeComponent},
  {path:"doctor-home", component:DoctorHomeComponent},
  {path:"doctors", component:DoctorsComponent},
  {path:"patients", component:PatientsComponent},
  {path:"feedbacks", component:FeedbacksComponent},
  {path:"appointments", component: AppointmentsComponent},
  {path:"discharges", component: DischargesComponent},
  {path:"invoices", component: InvoicesComponent},
  {path: "docs", component: DocsComponent},
  {path:"pats", component: PatsComponent},
  {path:"appoints", component:AppointsComponent},
  {path: "invoic", component:InvoicComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
