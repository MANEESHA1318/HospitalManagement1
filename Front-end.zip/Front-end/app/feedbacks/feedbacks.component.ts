import { Component, OnInit } from '@angular/core';
import { Feedback } from './Feedback.model';
import { FeedbackService } from './feedback.service';

@Component({
  selector: 'app-feedbacks',
  templateUrl: './feedbacks.component.html',
  styleUrls: ['./feedbacks.component.css']
})
export class FeedbacksComponent implements OnInit {
  feedbacks:Feedback[] | undefined;
    constructor(private feedbackService:FeedbackService) { }
 

 ngOnInit(): void {
    this.feedbackService.getFeedbacks().subscribe((fed)=>{
      this.feedbacks = fed;
  });
  }

}

