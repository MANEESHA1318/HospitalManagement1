export interface Feedback
{
    feedback_id : number;
    p_comments:string;
    p_id:number;
    
 

}