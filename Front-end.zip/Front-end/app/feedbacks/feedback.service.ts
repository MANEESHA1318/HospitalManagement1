import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Feedback } from "./Feedback.model";


@Injectable()
export class FeedbackService{
    constructor(private httpClient:HttpClient){}

    getFeedbacks():Observable<Feedback[]>{
        return this.httpClient.get<Feedback[]>('http://localhost:8088/api/v1/feedbacks');
    }
}
