import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { AboutComponent } from './about/about.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { DoctorComponent } from './doctor/doctor.component';
import { DoctorsignupComponent } from './doctor/doctorsignup/doctorsignup.component';
import { PatientComponent } from './patient/patient.component';
import { PatientsignupComponent } from './patient/patientsignup/patientsignup.component';
import { AdminmainpageComponent } from './admin/adminmainpage/adminmainpage.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { PatienthomepageComponent } from './patienthomepage/patienthomepage.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { PopupComponent } from './doctor/popup/popup.component';
import { DoctorListComponent } from './doctor-list/doctor-list.component';
import { PatientsListComponent } from './patients-list/patients-list.component';
import { FormsModule } from '@angular/forms';
import { DoctorHomeComponent } from './doctor-home/doctor-home.component';
import { HttpClientModule } from '@angular/common/http';
import { DoctorSignUpService } from './services/doctorsignup.service';
import { AdminService } from './services/admin.service';
import { DoctorLoginService } from './services/doctorlogin.service';
import { DoctorsComponent } from './doctors/doctors.component';
import { DoctorService } from './doctors/doctors.service';
import { PatientProfileComponent } from './patient-profile/patient-profile.component';
import { DocProfileComponent } from './doc-profile/doc-profile.component';
import { FeedbackService } from './feedbacks/feedback.service';
import { PatientLoginService } from './services/patientlogin.service';
import { PatientSignUpService } from './services/patientsignup.service';
import { PatientsComponent } from './patients/patients.component';
import { PatientService } from './patients/patients.service';
import { FeedbacksComponent } from './feedbacks/feedbacks.component';
import { AppointmentsComponent } from './appointments/appointments.component';
import { AppointmentService } from './appointments/appointments.service';
import { DischargesComponent } from './discharges/discharges.component';
import { DischargeService } from './discharges/discharges.service';
import { InvoicesComponent } from './invoices/invoices.component';
import { InvoiceService } from './invoices/invoices.service';
import { DocsComponent } from './docs/docs.component';
import { DocComponent } from './docs/doc/doc.component';
import { DocService } from './docs/docs.service';
import { PatsComponent } from './pats/pats.component';
import { PatComponent } from './pats/pat/pat.component';
import { PatService } from './pats/pats.service';
import { AppointsComponent } from './appoints/appoints.component';
import { AppointComponent } from './appoints/appoint/appoint.component';
import { AppointService } from './appoints/appoints.service';
import { InvoicComponent } from './invoic/invoic.component';
import { invoicService } from './invoic/invoic.service';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    AboutComponent,
    FeedbackComponent,
    FooterComponent,
    HomeComponent,
    AdminComponent,
    DoctorComponent,
    DoctorsignupComponent,
    PatientComponent,
    PatientsignupComponent,
    AdminmainpageComponent,
    AppointmentComponent,
    PatienthomepageComponent,
    InvoiceComponent,
    PopupComponent,
    DoctorListComponent,
    PatientsListComponent,
    DoctorHomeComponent,
    DoctorsComponent,
    PatientProfileComponent,
    DocProfileComponent,
    PatientsComponent,
    FeedbacksComponent,
    AppointmentsComponent,
    DischargesComponent,
    InvoicesComponent,
    DocsComponent,
    DocComponent,
    PatsComponent,
    PatComponent,
    AppointsComponent,
    AppointComponent,
    InvoicComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [DoctorSignUpService,DoctorService,PatientService, AdminService, DoctorLoginService, FeedbackService, PatientLoginService,
    PatientSignUpService, FeedbackService, AppointmentService, DischargeService, InvoiceService, DocService, PatService, AppointService, invoicService
   ],
    bootstrap: [AppComponent]
  })
  export class AppModule { }
  