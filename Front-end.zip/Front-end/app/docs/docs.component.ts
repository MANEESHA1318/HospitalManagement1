import { Component, OnInit } from '@angular/core';
import { Doc } from './Doc.model';
import { DocService } from './docs.service';

@Component({
  selector: 'app-docs',
  templateUrl: './docs.component.html',
  styleUrls: ['./docs.component.css']
})
export class DocsComponent implements OnInit {
  docs:Doc[] | undefined;
    constructor(private docService:DocService) { }
  

 ngOnInit(): void {
    this.docService.getDocs().subscribe((d)=>{
      this.docs = d;
  });
  }

}
