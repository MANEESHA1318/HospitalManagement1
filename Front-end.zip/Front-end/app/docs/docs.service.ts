import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Doc } from "./Doc.model";


@Injectable()
export class DocService{
    constructor(private httpClient:HttpClient){}

    getDocs():Observable<Doc[]>{
        return this.httpClient.get<Doc[]>('http://localhost:8088/api/v1/doctors');
    }
}
