import { Component, OnInit } from '@angular/core';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { invoic } from './invoic.model';
import { invoicService } from './invoic.service';
@Component({
  selector: 'app-invoic',
  templateUrl: './invoic.component.html',
  styleUrls: ['./invoic.component.css']
})
export class InvoicComponent implements OnInit {
  invoic:invoic|undefined;
  pid:string|undefined;
  MedicineCost:number|undefined;
  RoomCharges:number|undefined;
  Doctorcharges:number|undefined;
  TotalAmount:number|undefined;
  
  constructor(private invoicService:invoicService) { }

  ngOnInit(): void {
    this.invoicService.sendRequest().subscribe((res)=>{
      this.invoic = res;
      this.pid = res.pid;
      this.MedicineCost = res.medicinecost;
      this.RoomCharges = res.RoomCharges;
      this.Doctorcharges = res.Doctorcharges;
      this.TotalAmount = res.TotalAmount;
      console.log(res);
    })
  }
  public convetToPDF()
{
var val = document.getElementById('contentToConvert') as HTMLCanvasElement;
html2canvas(val).then(canvas => {
// Few necessary setting options
var imgWidth = 208;
var pageHeight = 295;
var imgHeight = canvas.height * imgWidth / canvas.width;
var heightLeft = imgHeight;
 
const contentDataURL = canvas.toDataURL('image/png')
let pdf = new jsPDF('p', 'mm', 'a4'); // A4 size page of PDF
var position = 0;
pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)
pdf.save('Invoice.pdf'); // Generated PDF
});
}
}