import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoicComponent } from './invoic.component';

describe('InvoicComponent', () => {
  let component: InvoicComponent;
  let fixture: ComponentFixture<InvoicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InvoicComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
