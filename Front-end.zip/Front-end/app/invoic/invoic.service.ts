import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { invoic } from "./invoic.model";

@Injectable()
export class invoicService{
    constructor(private httpClient:HttpClient) {
        
    }
    sendRequest():Observable<invoic>{
        let headers = new HttpHeaders({
            'content-type': 'application/json',
         });
         return this.httpClient.get<invoic>(
            'http://localhost:8088/api/v1/invoice',
          {
            headers: headers,
          }
         ); 
    }
}