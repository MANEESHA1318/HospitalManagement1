export interface invoic{
    pid: string | undefined;
    medicinecost: number | undefined;
    RoomCharges: number | undefined;
    Doctorcharges: number | undefined;
    TotalAmount: number | undefined;
}