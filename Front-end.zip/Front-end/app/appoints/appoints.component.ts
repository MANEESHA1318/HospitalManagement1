import { Component, OnInit } from '@angular/core';
import { Appoint } from './Appoint.model';
import { AppointService } from './appoints.service';
@Component({
  selector: 'app-appoints',
  templateUrl: './appoints.component.html',
  styleUrls: ['./appoints.component.css']
})
export class AppointsComponent implements OnInit {
  appoints:Appoint[] | undefined;
  constructor(private appointService:AppointService) { }

 ngOnInit(): void {
    this.appointService.getAppoints().subscribe((app)=>{
      this.appoints = app;
  });
  }

}



