export class Appoint
{
    ap_id! : number;
    address!:  string;
    ap_date!:string;
    ap_status!:string;
    ap_time!:string;
    d_id!:number;
    disease!: string;
    p_id!:number;

}
