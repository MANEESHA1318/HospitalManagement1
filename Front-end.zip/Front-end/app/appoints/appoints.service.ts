import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Appoint } from "./Appoint.model";


@Injectable()
export class AppointService{
    constructor(private httpClient:HttpClient){}

    getAppoints():Observable<Appoint[]>{
        return this.httpClient.get<Appoint[]>('http://localhost:8088/api/v1/appointments');
    }
}
