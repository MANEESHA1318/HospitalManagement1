export class Discharge
{
    dpId!: number;
    amountPaid!:string;
    dischargeDate!:string;
    disease!:string;
    p_Id!:number;
    constructor() { }

}