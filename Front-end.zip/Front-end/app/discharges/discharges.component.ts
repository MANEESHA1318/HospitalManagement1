import { Component, OnInit } from '@angular/core';
import { Discharge } from './Discharge.model';
import { DischargeService } from './discharges.service';

@Component({
  selector: 'app-discharges',
  templateUrl: './discharges.component.html',
  styleUrls: ['./discharges.component.css']
})
export class DischargesComponent implements OnInit {
  discharges:Discharge[] | undefined;
  constructor(private dischargeService:DischargeService) { }

 ngOnInit(): void {
    this.dischargeService.getDischarges().subscribe((dis)=>{
      this.discharges = dis;
  });
  }

}