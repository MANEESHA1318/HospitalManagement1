import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-discharge',
  templateUrl: './discharge.component.html',
  styleUrls: ['./discharge.component.css']
})
export class DischargeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
