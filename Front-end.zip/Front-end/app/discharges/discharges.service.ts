import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Discharge } from "./Discharge.model";


@Injectable()
export class DischargeService{
    constructor(private httpClient:HttpClient){}

    getDischarges():Observable<Discharge[]>{
        return this.httpClient.get<Discharge[]>('http://localhost:8088/api/v1/dischargedpatientdetails');
    }
}
