import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DischargesComponent } from './discharges.component';

describe('DischargesComponent', () => {
  let component: DischargesComponent;
  let fixture: ComponentFixture<DischargesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DischargesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DischargesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
