import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doc-profile',
  templateUrl: './doc-profile.component.html',
  styleUrls: ['./doc-profile.component.css']
})
export class DocProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
