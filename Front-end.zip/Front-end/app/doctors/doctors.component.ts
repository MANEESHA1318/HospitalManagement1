import { Component, OnInit } from '@angular/core';
import { Doctor } from './Doctor.model';
import { DoctorService } from './doctors.service';

@Component({
  selector: 'app-doctors',
  templateUrl: './doctors.component.html',
  styleUrls: ['./doctors.component.css']
})
export class DoctorsComponent implements OnInit {
  doctors:Doctor[] | undefined;
    constructor(private doctorService:DoctorService) { }
   

 ngOnInit(): void {
    this.doctorService.getDoctors().subscribe((doc)=>{
      this.doctors = doc;
  });
  }
  }


