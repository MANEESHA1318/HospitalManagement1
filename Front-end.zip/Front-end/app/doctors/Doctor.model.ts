export interface Doctor
{
    d_name : string;
    gender:  string;
    username:string;
    password:string;
    contact_no:string;
    address:string;
    specialization: string

}