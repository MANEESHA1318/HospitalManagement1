import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Doctor } from "./Doctor.model";


@Injectable()
export class DoctorService{
    delete(id: any) {
      throw new Error('Method not implemented.');
    }
    constructor(private httpClient:HttpClient){}

    getDoctors():Observable<Doctor[]>{
        return this.httpClient.get<Doctor[]>('http://localhost:8088/api/v1/doctors');
    }

}
