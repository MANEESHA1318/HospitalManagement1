export class PatientSignUp {
    p_name!: string;
    username!: string;
    password!: string;
    p_gender!: string;
    p_contact_no!: string
    constructor() { }
}