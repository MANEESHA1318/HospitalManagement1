export class PatientLogin {
    username!: string;
    password!: string
    constructor() { }
}