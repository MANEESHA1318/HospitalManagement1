export class Feedback {
    p_id!: number;
    p_comments!: string
    constructor() {}
}
