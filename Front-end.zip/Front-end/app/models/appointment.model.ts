export class Appointment {
    p_id!: number;
    address!: string;
    ap_date!: Date; 
    ap_status!: string;
    disease!: string
    ap_time!: Date

}