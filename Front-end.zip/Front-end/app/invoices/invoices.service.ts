import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Invoice } from "./Invoice.model";


@Injectable()
export class InvoiceService{
    constructor(private httpClient:HttpClient){}

    getInvoices():Observable<Invoice[]>{
        return this.httpClient.get<Invoice[]>('http://localhost:8088/api/v1/invoice');
    }
}
