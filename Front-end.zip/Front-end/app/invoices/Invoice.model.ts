export interface Invoice
{
    id : number;
    doctorCharges:  number;
    medicineCost:number;
    pid:number;
    roomCharges:number;
    totalAmount:number

}