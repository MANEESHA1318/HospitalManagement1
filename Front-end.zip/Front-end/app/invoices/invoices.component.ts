import { Component, OnInit } from '@angular/core';
import { Invoice } from './Invoice.model';
import { InvoiceService } from './invoices.service';
@Component({
  selector: 'app-invoices',
  templateUrl: './invoices.component.html',
  styleUrls: ['./invoices.component.css']
})
export class InvoicesComponent implements OnInit {
  invoices:Invoice[] | undefined;
  constructor(private invoiceService:InvoiceService) { }

 ngOnInit(): void {
    this.invoiceService.getInvoices().subscribe((inn)=>{
      this.invoices = inn;
  });
  }

}

