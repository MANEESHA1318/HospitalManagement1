import { Component, OnInit } from '@angular/core';
import { Patient } from './Patient.model';
import { PatientService } from './patients.service';

@Component({
  selector: 'app-patients',
  templateUrl: './patients.component.html',
  styleUrls: ['./patients.component.css']
})

export class PatientsComponent implements OnInit {
  patients:Patient[] | undefined;
    constructor(private patientService:PatientService) { }
  

 ngOnInit(): void {
    this.patientService.getPatients().subscribe((pat)=>{
      this.patients = pat;
  });
  }

}

