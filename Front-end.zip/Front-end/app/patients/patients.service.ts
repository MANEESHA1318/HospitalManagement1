import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { Patient } from "./Patient.model";


@Injectable()
export class PatientService{
    constructor(private httpClient:HttpClient){}

    getPatients():Observable<Patient[]>{
        return this.httpClient.get<Patient[]>('http://localhost:8088/api/v1/patients');
    }
}
