export interface Patient
{
    username:string;
    password:string;
    p_id : number; 
    p_contact_no:string;
    p_gender:string;
    p_name:  string;
   
  

}

