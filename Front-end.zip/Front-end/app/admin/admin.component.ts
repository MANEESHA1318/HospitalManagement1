import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationStatus } from '../models/AuthenticationStatus.model';
import { AdminService } from '../services/admin.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  // adminlogin = new AdminLogin();
  // msg = "";
  // constructor(private _service:AdminLoginService, private _router: Router, private route:ActivatedRoute) { }
  authStatus: AuthenticationStatus | undefined;
  constructor(
    private adminService: AdminService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void { }
  onSubmit(form: NgForm) {
    console.log(form.value.username, form.value.password);

    this.adminService
    .authenticated(form.value.username, form.value.password)
    .subscribe((res) => {
      this.authStatus = res;
      if (this.authStatus.authenticated) {
        alert("Successfully logged in!")
        this.router.navigate(['/adminmainpage'], {relativeTo: this.route});
      }
      else {
        alert("Invalid Credentials!")
        this.router.navigate(['/admin'], { relativeTo: this.route});
        form.reset();
      }
    });
  }

}



  // loginAdmin(){
  //   this._service.loginAdminFromRemote(this.adminlogin).subscribe(
  //     data => {
  //       console.log("Response received");
  //       alert("Successfully Logged in!");
  //       this._router.navigate(['/adminmainpage'])

  //     },
  //     error => {
  //       console.log("Exception occured");
  //       alert("Invalid Credentials")
  //       this.msg=error.error;
  //     }
  //   )
  // }

  // This is main code:

//   this._service.loginAdminFromRemote(this.adminlogin).subscribe(
//     data => { console.log("response recieved")
//     this._router.navigate(['/adminmainpage'],{relativeTo:this.route})
//   },
//     error =>{ 
//       console.log("exception occured")
//       this.msg="Invalid Credentials!"
//   }
//   )
// }

//New code sir method






