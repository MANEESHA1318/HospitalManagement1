import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PatientSignUp } from 'src/app/models/patientsignup.model';
import { PatientSignUpService } from 'src/app/services/patientsignup.service';

@Component({
  selector: 'app-patientsignup',
  templateUrl: './patientsignup.component.html',
  styleUrls: ['./patientsignup.component.css']
})

export class PatientsignupComponent implements OnInit {
  patientsignup = new PatientSignUp();
  msg = "";
  constructor(private _service:PatientSignUpService, private _router: Router) { }
   
  ngOnInit(): void {
  }
  registerPatient(){
    this._service.registerPatientFromRemote(this.patientsignup).subscribe(
      data => {
        console.log("Response received");
        alert("Registration Successful!");
        this._router.navigate(['/patient'])

      },
      error => {
        console.log("Exception occured");
        this.msg=error.error;
      }
    )
  }
}


